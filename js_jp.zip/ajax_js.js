//ajax 통신을 가능하게 하는 객체. 
let request=new XMLHttpRequest();
//데이터 주소 설정
const url='./MOCK_DATA.json';
//데이터 형식 설정
console.log(request.readyState)//0

//바뀐 응답요청값을 얻을때는 onreadystatechange 속성의 
//readyState메서드를 활용 문법은 아래와 같다. 
request.onreadystatechange=function(){
    if (request.readyState==4 && request.status ==200){
        console.log(this.responseText)
        jsonfunc(this.responseText)
    } 
}
request.open("GET",url);
request.send();
//네트워크 통신으로 db받기
//받은 db를 가공해서 화면에 바인딩
function jsonfunc(responseText){
    console.log(responseText)
    let id
}
